var container;
var camera, scene, renderer, controls;
var imagedata;

init();
animate();

function init() {
    container = document.getElementById('container');
    scene = new THREE.Scene();

    // Настройка камеры: угол 45, смотрим издалека
    camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 1, 10000);
    camera.position.set(300, 300, 300); 

    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x333333, 1);
    container.appendChild(renderer.domElement);

    // Добавляем управление мышью
    controls = new THREE.OrbitControls(camera, renderer.domElement);

    // Свет: один яркий сверху, другой мягкий со всех сторон
    var spotlight = new THREE.PointLight(0xffffff, 1);
    spotlight.position.set(200, 500, 200);
    scene.add(spotlight);

    var ambient = new THREE.AmbientLight(0x404040, 0.5);
    scene.add(ambient);

    loadHeightmap('pics/plateau.jpg');

    window.addEventListener('resize', onWindowResize, false);
}

function loadHeightmap(path) {
    var canvas = document.createElement('canvas');
    var context = canvas.getContext('2d');
    var img = new Image();

    img.onload = function() {
        canvas.width = img.width;
        canvas.height = img.height;
        context.drawImage(img, 0, 0);
        imagedata = context.getImageData(0, 0, img.width, img.height);
        createTerrain();
    };
    img.src = path;
}

function getPixel(imagedata, x, y) {
    var position = (x + imagedata.width * y) * 4;
    return imagedata.data[position];
}

function createTerrain() {
    var geometry = new THREE.Geometry();
    var w = imagedata.width;
    var h = imagedata.height;

    // 1. Создание вершин с ощутимой высотой
    for (var j = 0; j < h; j++) {
        for (var i = 0; i < w; i++) {
            // Множитель 0.15 делает горы заметными. 
            // Вычитаем w/2 и h/2 чтобы гора была в центре координат (0,0,0)
            var heightValue = getPixel(imagedata, i, j) * 0.15; 
            geometry.vertices.push(new THREE.Vector3(i - w/2, heightValue, j - h/2));
        }
    }

    // 2. Создание треугольников и UV-координат
    for (var j = 0; j < h - 1; j++) {
        for (var i = 0; i < w - 1; i++) {
            var v1 = i + j * w;
            var v2 = (i + 1) + j * w;
            var v3 = (i + 1) + (j + 1) * w;
            var v4 = i + (j + 1) * w;

            geometry.faces.push(new THREE.Face3(v1, v2, v3));
            geometry.faces.push(new THREE.Face3(v1, v3, v4));

            // Рассчитываем UV (от 0 до 1)
            var u1 = i / (w - 1);
            var v_uv1 = j / (h - 1);
            var u2 = (i + 1) / (w - 1);
            var v_uv2 = (j + 1) / (h - 1);

            geometry.faceVertexUvs[0].push([
                new THREE.Vector2(u1, v_uv1),
                new THREE.Vector2(u2, v_uv1),
                new THREE.Vector2(u2, v_uv2)
            ]);
            geometry.faceVertexUvs[0].push([
                new THREE.Vector2(u1, v_uv1),
                new THREE.Vector2(u2, v_uv2),
                new THREE.Vector2(u1, v_uv2)
            ]);
        }
    }

    // Рассчитываем нормали для теней
    geometry.computeFaceNormals();
    geometry.computeVertexNormals();

    // Загрузка текстуры
    var loader = new THREE.TextureLoader();
    var tex = loader.load('pics/grasstile.jpg');
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(4, 4); // Повторение текстуры, чтобы она не была размытой

    var material = new THREE.MeshLambertMaterial({
        map: tex,
        side: THREE.DoubleSide
    });

    var mesh = new THREE.Mesh(geometry, material);
    scene.add(mesh);
    
    // Камера смотрит в центр горы
    controls.target.set(0, 0, 0);
}

function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}

function animate() {
    requestAnimationFrame(animate);
    if (controls) controls.update();
    renderer.render(scene, camera);
}